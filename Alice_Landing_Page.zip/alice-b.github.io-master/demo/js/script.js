// Prevent Carousel from pausing on mouseover

$('.carousel').carousel({
    pause: "false"
});
