// See https://github.com/dialogflow/dialogflow-fulfillment-nodejs
// for Dialogflow fulfillment library docs, samples, and to report issues
'use strict';
 
const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
const {Card, Suggestion} = require('dialogflow-fulfillment');
const BIGQUERY = require("@google-cloud/bigquery");

const BIGQUERY_CLIENT = new BIGQUERY({
projectId: "lifestylecoach-iowuti" // ** CHANGE THIS **
});

 
process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements
 
exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
 
  function welcome(agent) {
    agent.add(`Welcome to my agent!`);
  }
 
  function fallback(agent) {
    agent.add(`I didn't understand`);
    agent.add(`I'm sorry, can you try again?`);
  }

    function bodyMassIndex(agent) {
      let weight = request.body.queryResult.parameters.weight;
      let height = request.body.queryResult.parameters.height / 100;
      let bmi = (weight / (height * height)).toFixed(2);
      let result = 'Incorrect information';
      if (bmi < 18.5) {
          result = 'You seem to be too thin, dont worry I will suggest you tips and sugestions to keep you healthy';
      } else if (bmi < 23) {
          result = 'Awesome!!, you are in Good shape,I will keep you healthy as your were alwasy :) ';
      } else if (bmi < 25) {
          result = 'Your, shape is getting started, no worries!! I will keep you healthy';
      } else if (bmi < 30) {
          result = 'You seem to be fat, you need fitness & excirecise clasess, I will suggest you tips to keep you healthy.';
      } else {
          result = 'You are too fat, you need immediate attention';
      }
      agent.add(result);
  }
  function healthrisk(agent) {
    // Capture Parameters from the Current Dialogflow Context
    console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
    console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
    const OUTPUT_CONTEXTS = request.body.queryResult.outputContexts;
    //const EMAIL = OUTPUT_CONTEXTS[OUTPUT_CONTEXTS.length - 1].parameters["email.original"];
    //const ISSUE_CATEGORY = OUTPUT_CONTEXTS[OUTPUT_CONTEXTS.length - 1].parameters.category;
    //const ISSUE_TEXT = request.body.queryResult.queryText;
 

    // The SQL Query to Run
    const SQLQUERY = `WITH pred_table AS ( SELECT 13000 as avg_step_count, 2000 as avg_calories_Intake, 9 as Avg_hours_of_sleep,
    50 as avg_weight_kg, 164 as Height ) 
    SELECT   * FROM ML.PREDICT(MODEL fitbitdata.predict_riskv2_1, TABLE pred_table)`;

    const OPTIONS = {
      query: SQLQUERY,
      // Location must match that of the dataset(s) referenced in the query.
      location: "US",
      //params: {
       // category: ISSUE_CATEGORY
      //}
    };
    return BIGQUERY_CLIENT.query(OPTIONS)
      .then(results => {
        //Capture results from the Query
        console.log(JSON.stringify(results[0]));
        const QUERY_RESULT = results[0];
        const HEALTHRISK_PREDICTION = QUERY_RESULT[0].predicted_label;
    
        //Format the Output Message
        agent.add( "Prediction value is" + HEALTHRISK_PREDICTION
        );
        agent.add(
          new Card({
            title:
             "Prediction value is" + HEALTHRISK_PREDICTION,
            imageUrl:
              "https://developers.google.com/actions/images/badges/XPM_BADGING_GoogleAssistant_VER.png",
            text: "Issue description: ",
            buttonText: "Go to Ticket Record",
            buttonUrl: "https://assistant.google.com/"
          })
        );
        //agent.setContext({
        //  name: "submitticket-collectname-followup",
        //  lifespan: 2
        //});
      })
      .catch(err => {
        console.error("ERROR:", err);
      });
    }
  // // Uncomment and edit to make your own intent handler
  // // uncomment `intentMap.set('your intent name here', yourFunctionHandler);`
  // // below to get this function to be run when a Dialogflow intent is matched
  // function yourFunctionHandler(agent) {
  //   agent.add(`This message is from Dialogflow's Cloud Functions for Firebase editor!`);
  //   agent.add(new Card({
  //       title: `Title: this is a card title`,
  //       imageUrl: 'https://developers.google.com/actions/images/badges/XPM_BADGING_GoogleAssistant_VER.png',
  //       text: `This is the body text of a card.  You can even use line\n  breaks and emoji! 💁`,
  //       buttonText: 'This is a button',
  //       buttonUrl: 'https://assistant.google.com/'
  //     })
  //   );
  //   agent.add(new Suggestion(`Quick Reply`));
  //   agent.add(new Suggestion(`Suggestion`));
  //   agent.setContext({ name: 'weather', lifespan: 2, parameters: { city: 'Rome' }});
  // }

  // // Uncomment and edit to make your own Google Assistant intent handler
  // // uncomment `intentMap.set('your intent name here', googleAssistantHandler);`
  // // below to get this function to be run when a Dialogflow intent is matched
  // function googleAssistantHandler(agent) {
  //   let conv = agent.conv(); // Get Actions on Google library conv instance
  //   conv.ask('Hello from the Actions on Google client library!') // Use Actions on Google library
  //   agent.add(conv); // Add Actions on Google library responses to your agent's response
  // }
  // // See https://github.com/dialogflow/fulfillment-actions-library-nodejs
  // // for a complete Dialogflow fulfillment library Actions on Google client library v2 integration sample

  // Run the proper function handler based on the matched Dialogflow intent name
  let intentMap = new Map();
  intentMap.set('Default Welcome Intent', welcome);
  intentMap.set('Default Fallback Intent', fallback);
  intentMap.set('00.LoginBMI', bodyMassIndex);
  intentMap.set('01.Health.Report', healthrisk);
  // intentMap.set('your intent name here', yourFunctionHandler);
  // intentMap.set('your intent name here', googleAssistantHandler);
  agent.handleRequest(intentMap);
});
